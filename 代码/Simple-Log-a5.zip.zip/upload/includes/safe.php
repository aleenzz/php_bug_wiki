<?php

$safe_act=array('');