<?php

$plugin_info['id'] = 'new_comment';
$plugin_info['plugin_point'] = '1';
$plugin_info['name'] = '最新评论';
$plugin_info['desc'] = '在边栏显示最新评论';
$plugin_info['author'] = 'pengwenfei';
$plugin_info['version'] = '1.0';
$plugin_info['cp_type'] =0;
$plugin_info['install'] =true;

?>