<?php

$plugin_info['id'] = 'new_article';
$plugin_info['plugin_point'] = '1';
$plugin_info['name'] = '最新文章';
$plugin_info['desc'] = '在边栏显示最新文章';
$plugin_info['author'] = 'pengwenfei';
$plugin_info['version'] = '1.0';
$plugin_info['cp_type'] =0;
$plugin_info['install'] =true;

?>