<?php

class WxPayConfig
{
const APPID = IN_WXAPPID;
const MCHID = IN_WXMCHID;
const KEY = IN_WXKEY;
const APPSECRET = IN_WXAPPSECRET;
const SSLCERT_PATH = '../cert/apiclient_cert.pem';
const SSLKEY_PATH = '../cert/apiclient_key.pem';
const CURL_PROXY_HOST = "0.0.0.0";
const CURL_PROXY_PORT = 0;
const REPORT_LEVENL = 1;
}
?>