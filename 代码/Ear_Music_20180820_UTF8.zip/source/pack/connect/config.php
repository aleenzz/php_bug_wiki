<?php
$oauth = array(
        'appid' => IN_QQAPPID,
        'appkey' => IN_QQAPPKEY,
        'api' => array(
                'get_user_info' => '1',
                'get_info' => '1',
                'add_t' => '1',
                'add_share' => '1'
        ),
        'session' => '0',
        'debug' => '0'
);
?>